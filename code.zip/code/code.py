
# coding: utf-8

# In[104]:


import hashlib
import base64
import requests
import json


# In[105]:


def md5_func(filename):
    hasher = hashlib.md5()
    with open(filename, 'rb') as afile:
        buf = afile.read()
        hasher.update(buf)
    return hasher.hexdigest()


# In[106]:


def base64_func(filename):
    encoded_string=''
    with open(filename, "rb") as pdf_file:
        encoded_string = base64.b64encode(pdf_file.read())
    return encoded_string 


# In[107]:


def create_data():
    data={
    "email": "delianeb1@gmail.com",
    "name": "Eliane Delwende Birba",
    "position": "Machine Learning Scientist",
    "notes": "You can find examples of my work in my GitHub repo at https://github.com/delwende.",
    "phone": "(46+) 0738463212",
    "documents": {
        "resume": {
            "content":base64_func('resume.pdf') ,
            "md5": md5_func('resume.pdf')
        },
        "cover_letter": {
            "content": base64_func('coverletter.pdf'),
            "md5": md5_func('coverletter.pdf')
        },
        "code": {
            "content": base64_func('code.zip'),
            "md5": md5_func('code.zip'),
            "filename": "code.zip"
        }
    },
    "test_or_submit": "submit"
    }
    return data


# In[122]:


def send_message_to_Arterys (url,data):
    headers = {
        'Content-Type': 'application/json',
    }
    
    response = requests.post(url, headers=headers, 
                             data=json.dumps(data))
    response.raise_for_status()
    print response.status_code


# In[123]:


if __name__ == '__main__':
    url = 'https://resumeapi.arterys.com/api/submission/4c432be9-3f33-4ad6-88d2-cbb524f58e1e'
    data=create_data()
    send_message_to_Arterys(url,data)
    

